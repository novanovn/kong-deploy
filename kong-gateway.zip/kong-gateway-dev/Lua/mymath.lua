_G.mmath = {
    -- sub: function(x,y)
    --     return x-y
    -- end
}


function mmath.sub(x, y)
    return x-y
end

function mmath.add(x, y)
    return x+y
end

function mmath.power(x, y)
    return x^y
end


return mmath