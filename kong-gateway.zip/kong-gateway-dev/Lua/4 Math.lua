x = 12.1

print(type(x))

local str = "22"

print(type(tonumber(str)))

print(20 ^ 3)

print(math.random())
-- print(math.randomseed(2))
print(math.pi)
print(os.time())
print(math.random(10))
print(math.random(10, 50))
print(math.min(10, 3, 7, -9, 0, 8))
print(math.max(10, 3, 7, -9, 0, 8))
print(math.floor(3.15))
print(math.ceil(3.15))
print(math.sin(3.15))
print(math.cos(3.15))
print(math.tan(3.15))