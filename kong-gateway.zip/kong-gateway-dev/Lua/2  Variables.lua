local x = 8
print(x)

_G.GlobalVar = 10