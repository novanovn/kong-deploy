print("Hello World!")


-- nil 
-- number 1 2 -99 9.87
-- string "hello" "world"
-- boolean true false
-- tables 