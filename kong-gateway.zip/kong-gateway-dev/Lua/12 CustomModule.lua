local mod = require("mymath")

print(mod.sub(7,3))
print(mod.add(7,3))
print(mod.power(7,3))